Please do not submit a Pull Request via GitHub. Buildroot makes use of a
[mailing list](http://lists.buildroot.org/mailman/listinfo/buildroot) for patch submission and review.
See [submitting your own patches](http://buildroot.org/manual.html#submitting-patches) for more info.

Thanks for your help!

